# Task 3 Secure Coding Review

## Project
A small Python and SQLite demonstration used to review SQL query construction. This is a learning sample, not an audit of an employer's system.

## Files
- `insecure_original.py`: intentionally vulnerable baseline used to identify the issue.
- `app.py`: corrected example using a parameterized query and closing the database connection.
- `review_notes.md`: scope, finding, remediation, and limitations.

## Reproduce the static scan
Use a Python virtual environment as set up during the exercise. From this folder:

```bash
python -m bandit insecure_original.py
python -m bandit app.py
```

The screenshots from the exercise show Bandit flagging the original string-built SQL query as B608 (medium severity, low confidence), and the post-fix scan reporting no issues identified. Static analysis is a useful check but does not prove that an application is secure.

## Main security lesson
Use SQL parameters for values supplied at runtime. Never insert untrusted data into SQL syntax by concatenating strings.
