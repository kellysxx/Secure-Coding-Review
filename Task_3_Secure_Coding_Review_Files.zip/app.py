"""Safer parameterized-query version for the secure-coding review exercise."""
import sqlite3

def find_user(name):
    connection = sqlite3.connect("users.db")
    query = "SELECT * FROM users WHERE name = ?"
    try:
        return connection.execute(query, (name,)).fetchall()
    finally:
        connection.close()
